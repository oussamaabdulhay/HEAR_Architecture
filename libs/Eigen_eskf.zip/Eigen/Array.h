#ifndef EIGEN_ARRAY_MODULE_H
#define EIGEN_ARRAY_MODULE_H

// include Core first to handle Eigen2 support macros
#include "Core"

#ifndef EIGEN2_SUPPORT
  #error The Eigen/Array header does no longer exist in Eigen3. All that functionality has moved to Eigen/Core.
#endif

#endif // EIGEN_ARRAY_MODULE_H